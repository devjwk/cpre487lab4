# CprE 487/587 Lab 4 - Quantization and Reduced Precision (Team 06)

Authors: Zach Dixon, Jongwoo Kim

## Layout

```
util/                         notebook + helper scripts (Sections 3, 4, 5)
implementations/
  float_quant_framework/      fp32 model   (QUANT_BITS 32)
  8bit_quant_framework/       8-bit model  (QUANT_BITS 8)
  4bit_quant_framework/       4-bit model  (QUANT_BITS 4)
  2bit_quant_framework/       2-bit model  (QUANT_BITS 2)
```

The four `implementations/` folders are the same C++ framework (our Lab 2 code plus quantization).
Each one is already configured for its bit width, so no flags are needed.

## Build and run (in any implementation folder)

```bash
make build
./build/ml          # framework tests; quantized builds also print per-layer error vs fp32 and top-1 checks
./build/ml val      # top-1 / top-10 accuracy and latency over the 1,000 validation images
./build/ml val 100  # same, first 100 images only
```

Expected `./build/ml val` accuracy (top-1 / top-10): fp32 23.5% / 60.5%, 8 bit 23.8% / 60.4%,
4 bit 6.6% / 24.1%, 2 bit 0.3% / 4.6%.

## Changing the quantization level

The bit width is one preprocessor flag, `QUANT_BITS` in `src/Config.h` (32, 8, 4 or 2). It can also be
overridden at build time: `make clean && make build QUANT_BITS=4`. A quantized build loads its
parameters from `data/model/q<bits>/`; the fp32 build loads `data/model/*.bin`. Each folder here ships
only the parameter files for its own bit width.

## What changed from the Lab 2 framework

| File | Change |
|---|---|
| `src/Config.h` | `QUANT_BITS` flag |
| `src/Quant.h` | quantization parameters, `quantize` / `dequantize`, parameter-file loader |
| `src/layers/Convolutional.*`, `Dense.h` | `computeQuantized`: int8 MACs into an int32 accumulator, dequantize, ReLU, requantize |
| `src/layers/MaxPooling.h`, `Flatten.h` | work directly on int8 data |
| `src/ML.cpp` | model built from `QUANT_BITS`, `runQuantCompare`, `runValidation` (`./build/ml val`) |

## Data

| Path | Contents |
|---|---|
| `data/model/` | weights and biases (fp32, or `q<bits>/` with int8 weights, int32 biases, `quant_params.txt`) |
| `data/image_N.bin`, `data/image_N_data/` | three test images and their fp32 reference layer outputs |
| `data/val/` | 1,000 validation images (uint8) and labels (int32) |

## util

| File | Purpose |
|---|---|
| `lab4_06.ipynb` | Lab 1 notebook extended for Lab 4 (activation profiling, validation export) |
| `weight_hist.py` | Section 3.2: weight histograms and weight/bias min-max |
| `act_minmax.py` | Section 3.3: activation min/max/avg over 1,000 training images -> `activation_ranges.json` |
| `quantize_export.py` | Sections 4, 5.2: scales, zero-points, quantized weights/biases for a given bit width |
| `export_val.py` | Section 5.1: export 1,000 validation images and labels |
| `plot_channel.py` | Section 5.3: same channel at fp32 / 8 / 4 / 2 bit |

`act_minmax.py` and `export_val.py` run inside the notebook (`%run -i <script>`) after the dataset and
model cells. The scripts were written for a single framework folder holding every bit width, so they
default to `../framework/data`; pass the data/model directory as an argument to use them with the
folders here, for example
`python3 quantize_export.py 8 ../implementations/float_quant_framework/data/model`.
